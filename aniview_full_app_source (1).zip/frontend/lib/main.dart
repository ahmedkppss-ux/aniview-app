import 'package:flutter/flutter.dart';
import 'home.dart';

void main() {
  runApp(const AniviewApp());
}

class AniviewApp extends StatelessWidget {
  const AniviewApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ANIVIEW',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0C0C0E),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF7B5BFA),
          surface: Color(0xFF16161A),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
