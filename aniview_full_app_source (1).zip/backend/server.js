const express = require('express');
const cors = require('cors');
const { fetchAutoContent } = require('./scraper');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/api/trending', async (req, res) => {
    try {
        const data = await fetchAutoContent();
        res.json({ success: true, data });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Aniview Server running on port ${PORT}`));
